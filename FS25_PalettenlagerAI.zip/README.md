# PalettenlagerAI (Mod folder: schilly)

Dieses ZIP enthält das Mod-Skeleton im Ordner 'schilly':
- GUI mit NumberInputDialog
- StorageManager (multiplayer-fähig)
- TransferEvent + SyncEvent
- Placeable skeleton (placeholder I3D)

Installation:
1. Entpacke PalettenlagerAI.zip
2. Kopiere den Ordner 'schilly' in deinen Mods-Ordner des Spiels
3. Starte FS25, aktiviere den Mod und teste im Spiel

Hinweis: Ersetze das placeholder I3D durch dein echtes Modell für das Placeable.