-- NumberInputDialog.lua
NumberInputDialog = {}
NumberInputDialog.CONTROLS = { "promptText", "inputField", "btnOk", "btnCancel" }
NumberInputDialog_mt = Class(NumberInputDialog, ScreenElement)

NumberInputDialogModule = NumberInputDialogModule or {}
NumberInputDialogModule.pending = NumberInputDialogModule.pending or nil

function NumberInputDialog.new(target)
    local self = ScreenElement.new(target)
    setmetatable(self, NumberInputDialog_mt)
    return self
end

function NumberInputDialog:loadFromXML(xmlFile, key)
    ScreenElement.loadFromXML(self, xmlFile, key)
    return true
end

function NumberInputDialog:onOpen()
    ScreenElement.onOpen(self)
    if NumberInputDialogModule.pending ~= nil then
        local p = NumberInputDialogModule.pending
        if self.promptText ~= nil and self.promptText.setText ~= nil then
            self.promptText:setText(p.prompt or "")
        end
        if self.inputField ~= nil and self.inputField.setText ~= nil then
            self.inputField:setText(tostring(p.default or ""))
        end
        self.callback = p.callback
        NumberInputDialogModule.pending = nil
    else
        if self.promptText ~= nil and self.promptText.setText ~= nil then
            self.promptText:setText("")
        end
        if self.inputField ~= nil and self.inputField.setText ~= nil then
            self.inputField:setText("")
        end
        self.callback = nil
    end
end

function NumberInputDialog:onClickOk()
    local text = ""
    if self.inputField ~= nil and self.inputField.getText ~= nil then
        text = self.inputField:getText()
    end
    local num = tonumber(text)
    if self.callback ~= nil then
        self.callback(num)
    end
    g_gui:closeScreenByName("NumberInputDialog")
end

function NumberInputDialog:onClickCancel()
    if self.callback ~= nil then
        self.callback(nil)
    end
    g_gui:closeScreenByName("NumberInputDialog")
end

function NumberInputDialogModule.open(prompt, defaultValue, callback)
    NumberInputDialogModule.pending = { prompt = prompt, default = defaultValue, callback = callback }
    if g_gui ~= nil then
        g_gui:showScreen("NumberInputDialog")
    end
end