PalletWarehouse = {}
PalletWarehouse_mt = Class(PalletWarehouse)

function PalletWarehouse.new(isServer, isClient, customMt)
    local self = {}
    setmetatable(self, customMt or PalletWarehouse_mt)
    self.node = nil
    self.storeTrigger = nil
    self.takeTrigger = nil
    self.displayNode = nil
    self.farmOwner = 0
    return self
end

function PalletWarehouse:load(node, xmlFile, key)
    self.node = node
    self.storeTrigger = Utils.getNoNil(getChildByName(node, "storeTrigger"), self.storeTrigger)
    self.takeTrigger = Utils.getNoNil(getChildByName(node, "takeTrigger"), self.takeTrigger)

    if self.storeTrigger ~= nil then
        addTrigger(self.storeTrigger, "onStoreTrigger", self)
    end
    if self.takeTrigger ~= nil then
        addTrigger(self.takeTrigger, "onTakeTrigger", self)
    end

    self.displayNode = Utils.getNoNil(getChildByName(node, "displayNode"), self.displayNode)
    return true
end

function PalletWarehouse:onStoreTrigger(triggerId, otherId, onEnter, onLeave, onStay)
    if not onEnter then
        return
    end

    local vehicle = g_currentMission.nodeToVehicle[otherId]
    if vehicle == nil or vehicle.getFillUnitCount == nil then
        return
    end

    local farmId = g_currentMission.controlledFarmId or 0

    for i = 1, vehicle:getFillUnitCount() do
        local fillLevel = vehicle:getFillUnitFillLevel(i)
        local fillType = vehicle:getFillUnitFillType(i)
        if fillLevel ~= nil and fillLevel > 0 and fillType ~= nil then
            local params = { fillTypeIndex = fillType, amount = fillLevel }
            if g_server == nil and g_client ~= nil then
                g_client:getServerConnection():sendEvent(AdvancedStorageTransferEvent.new(nil, "store", farmId, params))
            else
                if g_server ~= nil then
                    g_server:broadcastEvent(AdvancedStorageTransferEvent.new(nil, "store", farmId, params))
                end
            end
        end
    end
end

function PalletWarehouse:onTakeTrigger(triggerId, otherId, onEnter, onLeave, onStay)
    if not onEnter then
        return
    end

    local vehicle = g_currentMission.nodeToVehicle[otherId]
    if vehicle == nil then
        return
    end

    -- Beispiel: beim Betreten des "Take"-Triggers wird eine standardmäßige Menge entnommen.
    local farmId = g_currentMission.controlledFarmId or 0
    local fillTypeIndex = 1
    local amount = 100

    local params = { fillTypeIndex = fillTypeIndex, amount = amount, targetFarmId = farmId }
    if g_server == nil and g_client ~= nil then
        g_client:getServerConnection():sendEvent(AdvancedStorageTransferEvent.new(nil, "transfer", farmId, params))
    else
        if g_server ~= nil then
            g_server:broadcastEvent(AdvancedStorageTransferEvent.new(nil, "transfer", farmId, params))
        end
    end
end

function PalletWarehouse:update(dt)
    -- Update kann bei Bedarf verwendet werden, um eine Anzeige im Spiel zu aktualisieren.
    if self.displayNode == nil or g_advancedStorageManager == nil then
        return
    end

    local farmId = self.farmOwner or 0
    local list = g_advancedStorageManager:getAllForFarm(farmId)
    -- Beispiel: erstelle eine einfache Textdarstellung; für echte Anzeige muss Engine-API verwendet werden.
    local s = ""
    for ft, amt in pairs(list) do
        local ftDef = nil
        if g_fillTypeManager ~= nil then
            ftDef = g_fillTypeManager:getFillTypeByIndex(ft)
        end
        local name = ftDef and ftDef.title or tostring(ft)
        s = s .. string.format("%s: %.0f\n", name, amt)
    end

    -- Falls du ein Text-Node auf dem I3D hast, setze dort die Anzeige (engine-spezifisch).
    -- Beispielplatzhalter (funktioniert so nicht ohne passende Engine-API):
    -- setText(self.displayNode, s)
end

function PalletWarehouse:delete()
    -- Entferne Trigger bei Löschen
    if self.storeTrigger ~= nil then
        removeTrigger(self.storeTrigger)
        self.storeTrigger = nil
    end
    if self.takeTrigger ~= nil then
        removeTrigger(self.takeTrigger)
        self.takeTrigger = nil
    end
    self.node = nil
end