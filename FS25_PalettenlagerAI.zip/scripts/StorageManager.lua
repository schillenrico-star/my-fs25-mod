-- StorageManager.lua
StorageManager = {}
StorageManager_mt = Class(StorageManager)

function StorageManager.new(isServer, isClient)
    local self = setmetatable({}, StorageManager_mt)
    self.isServer = isServer
    self.isClient = isClient
    self.storage = {} -- storage[farmId] = { [fillTypeIndex] = amount }
    return self
end

-- Helper: ensure farm table exists
function StorageManager:ensureFarm(farmId)
    if self.storage[farmId] == nil then
        self.storage[farmId] = {}
    end
    return self.storage[farmId]
end

-- Get amount for farm + fillTypeIndex
function StorageManager:getAmount(farmId, fillTypeIndex)
    local farm = self.storage[farmId]
    if farm == nil then return 0 end
    return farm[fillTypeIndex] or 0
end

-- Get all goods for a farm (returns table {fillTypeIndex -> amount})
function StorageManager:getAllForFarm(farmId)
    local farm = self.storage[farmId] or {}
    -- return shallow copy
    local copy = {}
    for k,v in pairs(farm) do copy[k] = v end
    return copy
end

-- Add amount (positive to add, negative to remove). Returns actual delta applied.
function StorageManager:changeAmount(farmId, fillTypeIndex, delta)
    local farm = self:ensureFarm(farmId)
    local cur = farm[fillTypeIndex] or 0
    local new = cur + delta
    if new < 0 then
        delta = -cur
        new = 0
    end
    farm[fillTypeIndex] = new
    return delta
end

-- Server-only: set the whole storage table (used for sync)
function StorageManager:setStorage(newStorage)
    self.storage = newStorage or {}
end

-- Save / Load to XML (called from Mission save/load)
function StorageManager:saveToXMLFile(xmlFile, key)
    setXMLBool(xmlFile, key .. "#exists", true)
    local idx = 0
    for farmId, farmTbl in pairs(self.storage) do
        local farmKey = string.format("%s.farm(%d)", key, idx)
        setXMLInt(xmlFile, farmKey .. "#id", farmId)
        local j = 0
        for fillTypeIndex, amount in pairs(farmTbl) do
            local entryKey = farmKey .. string.format(".entry(%d)", j)
            setXMLInt(xmlFile, entryKey .. "#fillTypeIndex", fillTypeIndex)
            setXMLFloat(xmlFile, entryKey .. "#amount", amount)
            j = j + 1
        end
        idx = idx + 1
    end
end

function StorageManager:loadFromXMLFile(xmlFile, key)
    self.storage = {}
    if not hasXMLProperty(xmlFile, key .. "#exists") then
        return
    end
    local idx = 0
    while true do
        local farmKey = string.format("%s.farm(%d)", key, idx)
        if not hasXMLProperty(xmlFile, farmKey .. "#id") then break end
        local farmId = getXMLInt(xmlFile, farmKey .. "#id")
        self.storage[farmId] = {}
        local j = 0
        while true do
            local entryKey = farmKey .. string.format(".entry(%d)", j)
            if not hasXMLProperty(xmlFile, entryKey .. "#fillTypeIndex") then break end
            local fillTypeIndex = getXMLInt(xmlFile, entryKey .. "#fillTypeIndex")
            local amount = getXMLFloat(xmlFile, entryKey .. "#amount")
            self.storage[farmId][fillTypeIndex] = amount
            j = j + 1
        end
        idx = idx + 1
    end
end

-- Convenience: helper to return human-readable list for UI: { {fillTypeIndex=..., fillTypeName=..., amount=...}, ... }
function StorageManager:getListForUI(farmId)
    local out = {}
    local farm = self.storage[farmId] or {}
    for fillTypeIndex, amount in pairs(farm) do
        local fillType = g_fillTypeManager:getFillTypeByIndex(fillTypeIndex)
        local name = fillType and fillType.title or ("fillType" .. tostring(fillTypeIndex))
        table.insert(out, {fillTypeIndex = fillTypeIndex, name = name, amount = amount})
    end
    table.sort(out, function(a,b) return a.name < b.name end)
    return out
end

-- Debug
function StorageManager:printAll()
    for farmId, farmTbl in pairs(self.storage) do
        print("Farm", farmId)
        for i,v in pairs(farmTbl) do
            print("  FT", i, "=", v)
        end
    end
end