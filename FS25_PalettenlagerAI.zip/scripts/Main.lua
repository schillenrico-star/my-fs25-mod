MainModClass = {}
MainModClass.actionEventId = nil

local function init()
    FSBaseMission.registerActionEvents = Utils.appendedFunction(FSBaseMission.registerActionEvents, MainModClass.registerActionEvents)
    Mission00.load = Utils.appendedFunction(Mission00.load, MainModClass.onLoadMission)
    Mission00.unload = Utils.appendedFunction(Mission00.unload, MainModClass.onUnloadMission)
    Mission00.save = Utils.appendedFunction(Mission00.save, MainModClass.onSaveMission)
end

function MainModClass.onLoadMission(mission)
    if g_advancedStorageManager == nil then
        g_advancedStorageManager = StorageManager.new(mission.isServer, mission.isClient)
    end
    if mission.savegameDirectory ~= nil and g_advancedStorageManager.loadFromXMLFile ~= nil then
        local xmlFile = loadXMLFile("advancedStorageSave", mission:getMapSavegameFilename())
        if xmlFile ~= 0 then
            g_advancedStorageManager:loadFromXMLFile(xmlFile, "advancedStorage")
            delete(xmlFile)
        end
    end
end

function MainModClass.onSaveMission(mission, savegameDirectory)
    if g_advancedStorageManager ~= nil and g_advancedStorageManager.saveToXMLFile ~= nil then
        local xmlFile = loadXMLFile("advancedStorageSave", mission:getMapSavegameFilename())
        if xmlFile ~= 0 then
            g_advancedStorageManager:saveToXMLFile(xmlFile, "advancedStorage")
            saveXMLFile(xmlFile)
            delete(xmlFile)
        end
    end
end

function MainModClass.onUnloadMission(mission)
    if g_advancedStorageManager ~= nil and type(g_advancedStorageManager.delete) == "function" then
        g_advancedStorageManager:delete()
    end
    g_advancedStorageManager = nil
end

function MainModClass.registerActionEvents(self, inputManager)
    if inputManager == nil then
        return
    end

    local _, actionEventId = inputManager:registerActionEvent("OPEN_STORAGE_MENU", self, MainModClass.toggleStorageMenu, false, true, false, true)
    self.actionEventId = actionEventId
end

function MainModClass.toggleStorageMenu(self)
    if g_gui ~= nil and g_gui.getIsScreenOpen ~= nil and g_gui:getIsScreenOpen("AdvancedStorageGUI") then
        g_gui:closeScreenByName("AdvancedStorageGUI")
    else
        if g_currentMission ~= nil and g_currentMission.controlledFarmId ~= nil and g_currentMission.controlledFarmId ~= 0 then
            g_gui:showScreen("AdvancedStorageGUI")
        end
    end
end

init()