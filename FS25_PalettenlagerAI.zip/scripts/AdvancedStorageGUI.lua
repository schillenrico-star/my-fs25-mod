-- AdvancedStorageGUI.lua
AdvancedStorageGUI = {}
AdvancedStorageGUI.CONTROLS = { "warenTable", "btnKeep", "btnDistribute", "btnSell", "btnTransfer", "btnClose", "menuTitle" }
AdvancedStorageGUI_mt = Class(AdvancedStorageGUI, ScreenElement)

function AdvancedStorageGUI.new(target)
    local self = ScreenElement.new(target)
    setmetatable(self, AdvancedStorageGUI_mt)
    return self
end

function AdvancedStorageGUI:loadFromXML(xmlFile, key)
    ScreenElement.loadFromXML(self, xmlFile, key)
    self.selected = nil
    return true
end

function AdvancedStorageGUI:onOpen()
    ScreenElement.onOpen(self)
    self:refreshList()
end

function AdvancedStorageGUI:onClose()
    ScreenElement.onClose(self)
end

function AdvancedStorageGUI:refreshList()
    if g_currentMission == nil or g_advancedStorageManager == nil then return end
    local farmId = g_currentMission.controlledFarmId
    local list = g_advancedStorageManager:getListForUI(farmId)
    self.warenTable:removeElements()
    for i,entry in ipairs(list) do
        local item = {}
        item.wareName = entry.name
        item.wareAmount = string.format("%.0f", entry.amount)
        item.fillTypeIndex = entry.fillTypeIndex
        self.warenTable:addElement(item)
    end
    self.warenTable:reloadData()
end

function AdvancedStorageGUI:onSelectWare(element)
    if element == nil then
        self.selected = nil
    else
        self.selected = element.fillTypeIndex
    end
end

-- button handlers: send events to server
local function sendAction(actionType, params)
    if g_currentMission == nil then return end
    local farmId = g_currentMission.controlledFarmId
    if g_server == nil then
        -- client -> send to server
        g_client:getServerConnection():sendEvent(AdvancedStorageTransferEvent.new(nil, actionType, farmId, params))
    else
        -- singleplayer / local server: call server event directly
        g_server:broadcastEvent(AdvancedStorageTransferEvent.new(nil, actionType, farmId, params))
    end
end

function AdvancedStorageGUI:onActionKeep()
    if self.selected == nil then return end
    -- Prompt for amount: for demo, we store fixed amount or full; integrate input box for real mod
    local amount = 100 -- TODO: prompt input
    sendAction("store", { fillTypeIndex = self.selected, amount = amount })
end

function AdvancedStorageGUI:onActionTransfer()
    if self.selected == nil then return end
    local amount = 100 -- TODO: UI input for amount + select target farm
    local targetFarmId = 2 -- TODO: choose from UI, example
    sendAction("transfer", { fillTypeIndex = self.selected, amount = amount, targetFarmId = targetFarmId })
end

function AdvancedStorageGUI:onActionSell()
    if self.selected == nil then return end
    local amount = 100 -- TODO: prompt for input
    sendAction("sell", { fillTypeIndex = self.selected, amount = amount })
end

function AdvancedStorageGUI:onActionDistribute()
    if self.selected == nil then return end
    local amount = 100 -- TODO: UI/logic for distribution targets
    local targetFarmId = 2
    sendAction("distribute", { fillTypeIndex = self.selected, amount = amount, targetFarmId = targetFarmId })
end

function AdvancedStorageGUI:onClose()
    g_gui:closeScreenByName("AdvancedStorageGUI")
end