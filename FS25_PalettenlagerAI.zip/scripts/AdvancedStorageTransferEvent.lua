-- AdvancedStorageTransferEvent.lua
AdvancedStorageTransferEvent = {}
AdvancedStorageTransferEvent_mt = Class(AdvancedStorageTransferEvent, Event)
InitEventClass(AdvancedStorageTransferEvent, "AdvancedStorageTransferEvent")

-- actionType: "store", "distribute", "sell", "transfer" (server interprets)
function AdvancedStorageTransferEvent.emptyNew()
    local self = Event:new()
    setmetatable(self, AdvancedStorageTransferEvent_mt)
    return self
end

function AdvancedStorageTransferEvent.new(player, actionType, farmId, params)
    local self = AdvancedStorageTransferEvent.emptyNew()
    self.player = player -- optional
    self.actionType = actionType
    self.farmId = farmId
    self.params = params or {}
    return self
end

function AdvancedStorageTransferEvent:writeStream(streamId, connection)
    streamWriteString(streamId, tostring(self.actionType))
    streamWriteUIntN(streamId, self.farmId, 32)
    -- params: table: fillTypeIndex, amount, targetFarmId
    streamWriteInt32(streamId, self.params.fillTypeIndex or -1)
    streamWriteFloat32(streamId, self.params.amount or 0)
    streamWriteInt32(streamId, self.params.targetFarmId or -1)
end

function AdvancedStorageTransferEvent:readStream(streamId, connection)
    self.actionType = streamReadString(streamId)
    self.farmId = streamReadUIntN(streamId, 32)
    self.params = {}
    self.params.fillTypeIndex = streamReadInt32(streamId)
    self.params.amount = streamReadFloat32(streamId)
    self.params.targetFarmId = streamReadInt32(streamId)
    self:run(connection)
end

function AdvancedStorageTransferEvent:run(connection)
    -- Only server should modify the authoritative StorageManager
    if g_server == nil then
        -- client received: ignore (server will broadcast updates separately)
        return
    end

    -- Basic validation
    local srcFarmId = self.farmId
    local ft = self.params.fillTypeIndex
    local amount = self.params.amount
    local targetFarm = self.params.targetFarmId

    if amount == nil or amount <= 0 then return end
    if ft == nil or ft < 0 then return end

    local mgr = g_advancedStorageManager
    if not mgr then return end

    if self.actionType == "store" then
        -- store: add to farm storage
        local applied = mgr:changeAmount(srcFarmId, ft, amount)
        -- notify clients: simplest approach: broadcast a full storage snapshot (or create a dedicated sync event)
        g_server:broadcastEvent(AdvancedStorageSyncEvent.new(mgr.storage))
    elseif self.actionType == "transfer" then
        -- transfer between farms: move without cost
        if targetFarm == nil or targetFarm < 0 then return end
        local removed = mgr:changeAmount(srcFarmId, ft, -amount)
        if removed ~= 0 then
            mgr:changeAmount(targetFarm, ft, -removed * -1) -- add removed
        end
        g_server:broadcastEvent(AdvancedStorageSyncEvent.new(mgr.storage))
    elseif self.actionType == "sell" then
        -- Hook: implement price calculation & money awarding here
        -- Example placeholder: remove goods from storage and add money to farm
        local removed = mgr:changeAmount(srcFarmId, ft, -amount)
        if removed ~= 0 then
            -- TODO: compute price: use market API or custom table (not implemented here)
            local income = removed * 0 -- set real price here
            -- award money to farm (example function; check your FS version)
            -- g_currentMission:addMoney(income, srcFarmId, MoneyType.SELL)
        end
        g_server:broadcastEvent(AdvancedStorageSyncEvent.new(mgr.storage))
    elseif self.actionType == "distribute" then
        -- distribute: depends on target (own fields, factory). For now treat like transfer to targetFarm
        if targetFarm == nil or targetFarm < 0 then return end
        local removed = mgr:changeAmount(srcFarmId, ft, -amount)
        if removed ~= 0 then
            mgr:changeAmount(targetFarm, ft, -removed * -1)
        end
        g_server:broadcastEvent(AdvancedStorageSyncEvent.new(mgr.storage))
    end
end

-- Note: AdvancedStorageSyncEvent should be implemented to sync storage to clients.
-- Minimal implementation:
AdvancedStorageSyncEvent = {}
AdvancedStorageSyncEvent_mt = Class(AdvancedStorageSyncEvent, Event)
InitEventClass(AdvancedStorageSyncEvent, "AdvancedStorageSyncEvent")

function AdvancedStorageSyncEvent.emptyNew()
    local self = Event:new()
    setmetatable(self, AdvancedStorageSyncEvent_mt)
    return self
end

function AdvancedStorageSyncEvent.new(storage)
    local self = AdvancedStorageSyncEvent.emptyNew()
    self.storage = storage or {}
    return self
end

function AdvancedStorageSyncEvent:writeStream(streamId, connection)
    -- naive serialization: count farms, then for each: id, count entries, (fillTypeIndex, amount) pairs
    local farmCount = 0
    for _ in pairs(self.storage) do farmCount = farmCount + 1 end
    streamWriteUIntN(streamId, farmCount, 16)
    for farmId, farmTbl in pairs(self.storage) do
        streamWriteUIntN(streamId, farmId, 32)
        local entryCount = 0
        for _ in pairs(farmTbl) do entryCount = entryCount + 1 end
        streamWriteUIntN(streamId, entryCount, 16)
        for ft, amt in pairs(farmTbl) do
            streamWriteInt32(streamId, ft)
            streamWriteFloat32(streamId, amt)
        end
    end
end

function AdvancedStorageSyncEvent:readStream(streamId, connection)
    self.storage = {}
    local farmCount = streamReadUIntN(streamId, 16)
    for i=1,farmCount do
        local farmId = streamReadUIntN(streamId, 32)
        self.storage[farmId] = {}
        local entryCount = streamReadUIntN(streamId, 16)
        for j=1,entryCount do
            local ft = streamReadInt32(streamId)
            local amt = streamReadFloat32(streamId)
            self.storage[farmId][ft] = amt
        end
    end
    self:run(connection)
end

function AdvancedStorageSyncEvent:run(connection)
    -- Clients receive full sync and replace local storage snapshot
    if g_advancedStorageManager ~= nil then
        g_advancedStorageManager:setStorage(self.storage)
    end
end